import RPi.GPIO as GPIO
import time

# Use physical pin numbering
GPIO.setmode(GPIO.BOARD)

# Pin mapping (physical pins)
LED1_PIN = 32
LED2_PIN = 33
BTN1_PIN = 12
BTN2_PIN = 15

# Set up pins
GPIO.setup(LED1_PIN, GPIO.OUT, initial=GPIO.LOW)
GPIO.setup(LED2_PIN, GPIO.OUT, initial=GPIO.LOW)
GPIO.setup(BTN1_PIN, GPIO.IN)  # external pull-down
GPIO.setup(BTN2_PIN, GPIO.IN)  # external pull-down

print("Press the buttons... (Ctrl+C to exit)")

try:
    while True:
        # Control LED1 with BTN1
        if GPIO.input(BTN1_PIN):
            GPIO.output(LED1_PIN, GPIO.HIGH)
        else:
            GPIO.output(LED1_PIN, GPIO.LOW)

        # Control LED2 with BTN2
        if GPIO.input(BTN2_PIN):
            GPIO.output(LED2_PIN, GPIO.HIGH)
        else:
            GPIO.output(LED2_PIN, GPIO.LOW)

        time.sleep(0.01)  # small debounce delay

except KeyboardInterrupt:
    print("\nExiting...")
finally:
    GPIO.cleanup()
